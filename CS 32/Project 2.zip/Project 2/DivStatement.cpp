//
//  DivStatement.cpp
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#include "DivStatement.h"



using std::ostream;
using std::endl;

DivStatement::DivStatement(char variableName, int value)
: m_variableName( variableName ), m_value( value )
{
    
    m_variableName=variableName;
    m_value=value;
    
    
}

// The DivStatement version of execute() should make two changes to the
// state of the program:
//
//    * divide the character's value by the input value.
//    * increment the program counter

void DivStatement::execute(ProgramState * state, ostream &outf)
{
    if (m_value==0)
    {
        outf << "Divide by zero exception" << endl;
        exit(1);
    }
    
    state->divide(m_variableName,m_value);
    state->increaseCounter();
}