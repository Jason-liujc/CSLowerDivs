//
//  SubStatement.h
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#ifndef __Project_2__SubStatement__
#define __Project_2__SubStatement__


#include "Statement.h"

class SubStatement : public Statement
{
private:
    char m_variableName;
    int m_value;
    
    
public:
    SubStatement(char variableName, int value);
	
	virtual void execute(ProgramState * state, std::ostream &outf);
    
    virtual ~SubStatement(){};
    
};








#endif /* defined(__Project_2__SubStatement__) */
