//
//  SubStatement.cpp
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#include "SubStatement.h"

using std::ostream;

SubStatement::SubStatement(char variableName, int value)
: m_variableName( variableName ), m_value( value )
{
    
    m_variableName=variableName;
    m_value=value;
    
    
}



// The SubStatement version of execute() should make two changes to the
// state of the program:
//
//    * subtract the character's value by current value.
//    * increment the program counter.

void SubStatement::execute(ProgramState * state, ostream &outf)
{
    
    state->subtract(m_variableName,m_value);
    state->increaseCounter();
}