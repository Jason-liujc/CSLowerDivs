//
//  DotStatement.h
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#ifndef __Project_2__DotStatement__
#define __Project_2__DotStatement__

#include "Statement.h"
class DotStatement : public Statement
{
private:
    
 
    
    
public:
    DotStatement();
	
	virtual void execute(ProgramState * state, std::ostream &outf);
    virtual ~DotStatement(){};
    
};

#endif /* defined(__Project_2__DotStatement__) */
