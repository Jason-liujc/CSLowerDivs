//
//  DotStatement.cpp
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#include "DotStatement.h"




DotStatement::DotStatement()
{}



// The Retstatement version of execute() should make two changes to the
// state of the program:
//
//    *end the program

void DotStatement::execute(ProgramState * state, std::ostream &outf)
{
    state->changeEnding();
   
}