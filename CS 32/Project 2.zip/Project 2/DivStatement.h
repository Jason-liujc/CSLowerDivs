//
//  DivStatement.h
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#ifndef __Project_2__DivStatement__
#define __Project_2__DivStatement__


#include "Statement.h"


class DivStatement : public Statement
{
private:
    char m_variableName;
    int m_value;
    
    
public:
    DivStatement(char variableName, int value);
	
	virtual void execute(ProgramState * state, std::ostream &outf);
    virtual ~DivStatement(){};
    
    
};


#endif /* defined(__Project_2__DivStatement__) */
