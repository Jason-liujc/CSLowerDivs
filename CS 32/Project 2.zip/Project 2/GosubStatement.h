//
//  GosubStatement.h
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#ifndef __Project_2__GosubStatement__
#define __Project_2__GosubStatement__

#include "Statement.h"

class GosubStatement : public Statement
{
private:
    
    int m_value;
    
    
public:
    GosubStatement(int value);

	virtual void execute(ProgramState * state, std::ostream &outf);
    
    
    virtual ~GosubStatement(){};
};

#endif /* defined(__Project_2__GosubStatement__) */
