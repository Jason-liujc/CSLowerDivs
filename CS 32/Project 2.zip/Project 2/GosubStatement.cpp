//
//  GosubStatement.cpp
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#include "GosubStatement.h"

using std::ostream;
using std::endl;

GosubStatement::GosubStatement(int value)
: m_value( value )
{
    m_value=value;
    
    
}


// The Retstatement version of execute() should make two changes to the
// state of the program:
//
//    *go to the designated line
//    *remember the next line so when returns it behaves good. 


void GosubStatement::execute(ProgramState * state, ostream &outf)
{
    int line=state->mCounter()+1;

   
    state->GoSub(m_value, line);
     if (m_value>state->getMaxLine())
    {
        outf << state->getMessage() << endl;
        exit(1);
    }
    
    
}