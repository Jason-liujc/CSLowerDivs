//
//  RetStatement.cpp
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#include "RetStatement.h"
using std::endl;


RetStatement::RetStatement  ()
{
    
}


// The Retstatement version of execute() should make two changes to the
// state of the program:
//
//    * return to the nearest Gosub line (after the Gosub line)
//    * exit 1 if the stack if empty. 


void RetStatement::execute(ProgramState * state, std::ostream &outf)
{
    string testStr;
    
    
    int line=state->SubReturn();
    testStr=state->getMessage();
    if (testStr=="Illegal return statement")  //the example program posted did this.
    {
        outf << testStr << endl;
        exit(1);
    }
    state->Goto(line);
    
}