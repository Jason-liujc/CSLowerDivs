// ProgramState.h
//
// CS 32 / Summer 2014
// Project #2: What's Simple Is True
//
// The ProgramState class encapsulates the state of an executing Facile
// program.  The state of a Facile program consists of three parts:
//
//    * The program counter, which specifies the line number of the
//      statement that will execute next.
//    * An array of 26 integers, holding the current values of the 26
//      variables.
//    * A stack of integers, which is used to hold return lines for GOSUB
//      statements.
//
// I've provided you a start on this class, but you'll need to add methods
// to it as you go along.  In particular, you'll need methods to access and
// modify the state; these methods will be called primarily by the various
// execute() methods in the Statement subclasses, to allow the execution of
// a statement to change the state of a program.  For example, executing a
// GOTO statement will cause the program counter to be changed.

#ifndef PROGRAM_STATE_INCLUDED
#define PROGRAM_STATE_INCLUDED

#include "Stack.h"
#include <iostream>
using std::string;

class ProgramState
{
public:
	ProgramState(int numLines)
    {
        //initialization
        for (int i=0; i<26; i++)
        {
            chArray[i]=0;
        }
        totNum=numLines;
        m_numLines=1;
        m_ending=false;
    
    }
    
   
    
    void increaseCounter()
    {
        m_numLines++;
        
        
    }
    
    int mCounter()
    {
        return m_numLines;
        
        
    }
    
    int getValue(char a)
    {
        int pos=charToDigit(a);
        return chArray[pos];
        
        
    }
    void setValue(char a, int value)
    {
        int pos=charToDigit(a);
        chArray[pos]=value;
        
        
    }
    
    void add(char a, int value)
    {
        int pos=charToDigit(a);
        chArray[pos]=chArray[pos]+value;
        
        
    }
    
    void GoSub(int lineNumber, int currentLine)
    {
        m_numLines=lineNumber;
        
        if (lineNumber>m_maxLines)
        {
            messenger("Illegal jump instruction");
            
            
        }
        
        Stack1.push(currentLine);
    }
    
    void subtract(char a, int value)
    {
        int pos=charToDigit(a);
        chArray[pos]=chArray[pos]-value;
        
        
        
    }
    
    int Goto(int lineNum)
    {
        
        m_numLines=lineNum;
        
        if (lineNum>m_maxLines)
        {
            messenger("Illegal jump instruction");
            
            return 3;
        }
        return 1;
    }
    
    void multiply(char a, int value)
    {
        int pos=charToDigit(a);
        chArray[pos]=chArray[pos]*value;
        
        
        
    }
    int getMaxLine()
    {
        
        return m_maxLines;
    }
    
    void divide(char a, int value)
    {
        
        int pos=charToDigit(a);
        chArray[pos]=chArray[pos]/value;
        
    }
    
    int SubReturn()
    {
        if (Stack1.size()==0)
            messenger("Illegal return statement"); //again the example program did this. 
        
        
        int tempVar=Stack1.top();
        Stack1.pop();
        
        
        
        return tempVar;
    }
    
    
    int charToDigit(char a)
    {
        return a-'A';
    }

    void insertMax(int lines)
    {
        
        m_maxLines=lines;
        
    }
    
    void messenger(string message)
    {
        
        m_message=message;
        
    }
    
    string getMessage()
    {
        
        return m_message;
    }
    
    void changeEnding()
    {
        m_ending=true;
    }
    bool ending()
    {
        return m_ending;
    }
    
private:
	int m_numLines;
    int totNum;
    int m_maxLines;
    int m_currentLine;
    string m_message;
    int chArray[26]; //A being 0 position, B being 1 position......, Z being 25 positon.
    Stack<int> Stack1;
    bool m_ending;
 
};

#endif



