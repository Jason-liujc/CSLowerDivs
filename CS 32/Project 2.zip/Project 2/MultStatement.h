//
//  MultStatement.h
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#ifndef __Project_2__MultStatement__
#define __Project_2__MultStatement__

#include "Statement.h"


class MultStatement : public Statement
{
private:
    char m_variableName;
    int m_value;
    
    
public:
    MultStatement(char variableName, int value);
	
	virtual void execute(ProgramState * state, std::ostream &outf);
    
    virtual ~MultStatement(){};
    
};



#endif /* defined(__Project_2__MultStatement__) */
