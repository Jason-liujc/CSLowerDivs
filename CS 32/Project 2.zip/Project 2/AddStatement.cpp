//
//  AddStatement.cpp
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#include "AddStatement.h"

using std::ostream;

AddStatement::AddStatement(char variableName, int value)
: m_variableName( variableName ), m_value( value )
{
    
    m_variableName=variableName;
    m_value=value;
    
    
}

// The AddStatement version of execute() should make two changes to the
// state of the program:
//
//    * Add the input value to a character's value.
//    * increment the program counter



void AddStatement::execute(ProgramState * state, ostream &outf)
{
    
    state->add(m_variableName,m_value);
    state->increaseCounter();
}


