//
//  ifStatement.h
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#ifndef __Project_2__ifStatement__
#define __Project_2__ifStatement__
#include "Statement.h"
using std::string;

class ifStatement : public Statement
{
private:
    
    int m_value;
    string m_operater;
    char m_variable;
    int m_lineNum;
    
    
public:
    ifStatement(char variable, string operater, int value, int lineNum);
	
	virtual void execute(ProgramState * state, std::ostream &outf);
   
    virtual ~ifStatement(){};
    
    
};

#endif /* defined(__Project_2__ifStatement__) */
