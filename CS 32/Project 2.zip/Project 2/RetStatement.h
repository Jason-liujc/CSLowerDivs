//
//  RetStatement.h
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#ifndef __Project_2__RetStatement__
#define __Project_2__RetStatement__


#include "Statement.h"
class RetStatement : public Statement
{
private:
    
   
    
    
public:
    RetStatement();
	
	virtual void execute(ProgramState * state, std::ostream &outf);
    virtual ~RetStatement(){};
    
     
    
};


#endif /* defined(__Project_2__RetStatement__) */
