//
//  ifStatement.cpp
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#include "ifStatement.h"

using std::string;

using std::ostream;

//
//
//


ifStatement::ifStatement(char variable, string operater, int value, int lineNum)
: m_value( value ), m_operater(operater), m_variable(variable), m_lineNum(lineNum)
{
    
    m_operater=operater;
    m_lineNum=lineNum;
    m_variable=variable;
    m_value=value;
    
    
}


// The Retstatement version of execute() should make two changes to the
// state of the program:
//
//    *If expression correct do something.



void ifStatement::execute(ProgramState * state, ostream &outf)
{
    if (m_lineNum>state->getMaxLine())
    {
        outf << "Illegal jump instruction" << std::endl; 
        exit(1);
    }
    int value;
    bool truthCounter=false;
    value=state->getValue(m_variable);
    
    //below are different cases of oeprators.
    if (m_operater=="<")
    {
        if (value < m_value)
        {
            state->Goto(m_lineNum);
            truthCounter=true;
        }
        
        
    }
    else if (m_operater=="=")
    {
        if (value==m_value)
        {
            
            state->Goto(m_lineNum);
            truthCounter=true;
        }
        
        
        
    }
    else if (m_operater==">")
    {
        if (value>m_value)
        {
            
            state->Goto(m_lineNum);
            truthCounter=true;
        }
        
        
        
    }
    
    else if (m_operater=="<=")
    {
        
        if (value<=m_value)
        {
            
            state->Goto(m_lineNum);
            truthCounter=true;
        }
        
        
        
        
    }
    
    else if (m_operater==">=")
    {
        
        
        
        if (value>=m_value)
        {
            
            state->Goto(m_lineNum);
            truthCounter=true;
        }
        
        
        
    }
    if (!truthCounter)
    {
    state->increaseCounter();
    }
}