//
//  GotoStatement.cpp
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#include "GotoStatement.h"



using std::ostream;
using std::endl;

GotoStatement::GotoStatement(int value)
: m_value( value )
{
    
  
    m_value=value;
    
    
}


// The DivStatement version of execute() should make two changes to the
// state of the program:
//
//    * change the current line number.
//    * exit 1 if it's out of reach. 


void GotoStatement::execute(ProgramState * state, ostream &outf)
{
    int temp;
    temp=state->Goto(m_value);
    if (temp==3)
    {
        outf << state->getMessage() << endl;
        exit(1);
    }
    
    
    
}