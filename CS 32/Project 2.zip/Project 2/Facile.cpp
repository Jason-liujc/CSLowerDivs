// Lots of files! AMIRITE?
#include "Statement.h"
#include "LetStatement.h"
#include "PrintStatement.h"
#include "AddStatement.h"
#include "DivStatement.h"
#include "SubStatement.h"
#include "MultStatement.h"
#include "RetStatement.h"
#include "GotoStatement.h"
#include "DotStatement.h"
#include "GosubStatement.h"
#include "ifStatement.h"
#include <vector>
#include <string>
#include <sstream> 
#include <fstream>
#include <cstdlib>
#include <iostream>

//              Are you just gonna ignore the elephant in the code???
//                        ___      ___
//                        /   \____/   \
//                        /    / __ \    \
//                        /    |  ..  |    \
//                        \___/|      |\___/\
//                        | |_|  |_|      \
//                        | |/|__|\|       \
//                        |   |__|         |\
//                        |   |__|   |_/  /  \
//                        | @ |  | @ || @ |   '
//                        |   |~~|   ||   |
//                        'ooo'  'ooo''ooo'



using namespace std;

// parseProgram() takes a filename as a parameter, opens and reads the
// contents of the file, and returns an vector of pointers to Statement.
void parseProgram(istream& inf, vector<Statement *> & program);

// parseLine() takes a line from the input file and returns a Statement
// pointer of the appropriate type.  This will be a handy method to call
// within your parseProgram() method.
Statement * parseLine(string line);

// interpretProgram() reads a program from the given input stream
// and interprets it, writing any output to the given output stream.
// Note:  you are required to implement this function!
void interpretProgram(istream& inf, ostream& outf);
void manDistructor();



int main()
{
    cout << "Enter Facile program file name: ";
    string filename;
    getline(cin, filename);
    ifstream infile(filename.c_str());
    if (!infile)
    {
        cout << "Cannot open " << filename << "!" << endl;
        return 1;
    }
    interpretProgram(infile, cout);
}



void parseProgram(istream &inf, vector<Statement *> & program)
{
	program.push_back(nullptr);
	
	string line;
	while( ! inf.eof() )
	{
		getline(inf, line);
		program.push_back( parseLine( line ) );
	}
}


Statement * parseLine(string line)
{
	Statement * statement;	
	stringstream ss;
	string type;
	char var;
	int val;

	ss << line;
	ss >> type;
	
    
    //type is the first letter.
	if ( type == "LET" )
	{
		ss >> var;
		ss >> val;
		// Note:  Because the project spec states that we can assume the file
		//	  contains a syntactically legal Facile program, we know that
		//	  any line that begins with "LET" will be followed by a space
		//	  and then a variable (single character) and then an integer value.
		statement = new LetStatement(var, val);
    
	}
    
    else if (type== "PRINT")
    {
        ss >> var;
       
        statement = new PrintStatement(var);
        
    }
    
    else if ( type == "ADD" )
	{
		ss >> var;
		ss >> val;
		
		statement = new AddStatement(var, val);
        
	}
    else if ( type == "SUB" )
	{
		ss >> var;
		ss >> val;
		
		statement = new SubStatement(var, val);
        
	}
    
    else if ( type == "MULT" )
	{
		ss >> var;
		ss >> val;
		
		statement = new MultStatement(var, val);
        
	}
    
    else if ( type == "DIV" )
	{
		ss >> var;
		ss >> val;
		
		statement = new DivStatement(var, val);
        
	}
    else if ( type == "GOTO" )
	{
	
		ss >> val;
		
		statement = new GotoStatement(val);
        
	}
    
    else if ( type == "RETURN" )
	{
		
		
		statement = new RetStatement();
        
	}
    
    else if (type== "." || type =="END")
    {
      
        statement= new DotStatement();
    }
    
    else if (type== "GOSUB")
    {
        ss >> val;
        statement= new GosubStatement(val);
        
        
    }
    else if (type == "IF" )
    {
        string oper;
        int lineNum;
        string Dummy;
        
        ss >> var;
        ss >> oper;
        ss >> val;
        ss >> Dummy;
        ss >> lineNum;
        
        
        statement=new ifStatement(var, oper, val, lineNum);
        
        
    }
    else if (type=="")
    {
        //in case there's empty spaces.
    }
    
    else
    {
        // in case there's anything else.
    }
    
    

		
	return statement;
}


void interpretProgram(istream& inf, ostream& outf)
{
    int programSize;
    int counter=0;
    
	vector<Statement *> program;
    
	parseProgram( inf, program );
    
    programSize=(int)program.size()-1; // -1 here because the first vector element of program is irrelevant (NULL).
    
	ProgramState* m_state=new ProgramState(programSize);
    
    Statement * statement;
    
    m_state->insertMax(programSize);
    
    
   
    
    
    for (;;)
    {
       
        counter=m_state->mCounter();  // the program counter.
        
        
    statement=program.at(counter); //+1 here because the first vector is a NULL pointer.
    
        
    statement->execute(m_state,outf);
       if(m_state->ending())
           break;
        
    }
    
    
    
    int i=programSize;
    while (program.at(i)!=nullptr)   //here's a destructor. 
    {
        delete program.at(i);
        i--;
        
    }
   
    delete m_state;
    
}


