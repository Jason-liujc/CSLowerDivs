//
//  MultStatement.cpp
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#include "MultStatement.h"


using std::ostream;

MultStatement::MultStatement(char variableName, int value)
: m_variableName( variableName ), m_value( value )
{
    
    m_variableName=variableName;
    m_value=value;
    
    
}

// The MultStatement version of execute() should make two changes to the
// state of the program:
//
//    * multiply the character's value by the input value.
//    * increment the program counter



void MultStatement::execute(ProgramState * state, ostream &outf)
{
    
    state->multiply(m_variableName,m_value);
    state->increaseCounter();
}