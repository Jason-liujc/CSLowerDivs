#ifndef STACK_INCLUDED
#define STACK_INCLUDED

template <typename T>
class StackNode
{
public:
    //copy constructor
    StackNode (T value, StackNode* aPointer)
    {
        m_currentValue=value;
        myptr=aPointer;
        
    }
    
    T getValue()
    {
        return m_currentValue;
        
    }
    
    StackNode* getPrev()
    {
        return myptr;
    }
  
    
private:
    T m_currentValue;
  
    StackNode *myptr;
  
};


template <typename T>
class Stack
{
public:
    //a default cosntructor
	Stack()
    {
        m_top=nullptr;
        m_size=0;
        
    }
    
    
    
    ~Stack()
    {
        while(m_top!=nullptr)
        {
            StackNode<T> *temp=m_top;
            delete m_top;
           
            m_top=temp->getPrev();
            
            
        }
   
        
    }
    //put values in there
	void push(const T x)
    {
        StackNode<T> *temp=m_top;
        
        m_top=new StackNode<T>(x,temp); // dynamically allocate pointer m_top.
        m_size++;
        
    }
    
    
    
    //pop like the stack STL
	void pop()
    {
        
        if (m_size!=0)
        {
            StackNode<T> *temp2=m_top->getPrev();
            
            m_top=temp2;
            
            m_size--;
            
            
        }
        if (m_size==0)
        {
            m_top=nullptr; //I have to do something since it's void.
        }
    }
    
    
    //return the value of the top position.
	T top() const
    {
        if (m_top!=nullptr)
            return m_top->getValue();
        
        else
            return 0;
    }
    
    //see if the stack is empty.
	bool isempty() const
    {
        return m_size==0;
        
        
    }
    
    
    //return the size of the stack.
    int size()
    {
        return m_size;
        
    }

private:
    
	StackNode<T> * m_top;
    int m_size;
  
    
    
};


#endif

