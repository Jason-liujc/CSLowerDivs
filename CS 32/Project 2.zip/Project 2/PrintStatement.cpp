// PrintStatement.cpp:
#include "PrintStatement.h"

PrintStatement::PrintStatement(char variableName)
	: m_variableName( variableName )
{
    m_variableName=variableName;
}


// The PrintStatement version of execute() should make two changes to the
// state of the program:
//
//    * print the value!
//    * increment the program counter

void PrintStatement::execute(ProgramState * state, std::ostream &outf)
{
    int value;
    value=state->getValue(m_variableName);
    outf << value << std::endl;
    
    state->increaseCounter();
}


