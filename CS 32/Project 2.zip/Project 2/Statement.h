// Statement.h
//
// CS 32 / Summer 2014
// Project #2: What's Simple Is True
//
// This is the abstract Statement class, from which your various statement
// classes will need to extend.  There is only one method in the Statement
// class, an execute() method that executes the statement, making any
// necessary changes to the given ProgramState.

#ifndef STATEMENT_INCLUDED
#define STATEMENT_INCLUDED

#include "ProgramState.h"
#include <fstream>
#include <string> // for Visual C++ purposes. Other wise it doesn't compile.

class Statement
{
	
	
	// execute() also takes a ostream parameter;  if any output is to be  
	// written, write it to the given ostream.
	
    
public:
	virtual void execute(ProgramState*  state, std::ostream &outf) = 0;
    virtual ~Statement(){}; // Here you go! A virtual Destructor!
};



#endif

