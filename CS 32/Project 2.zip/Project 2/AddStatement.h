//
//  AddStatement.h
//  Project 2
//
//  Created by Jason on 7/12/14.
//  Copyright (c) 2014 Jason. All rights reserved.
//

#ifndef __Project_2__AddStatement__
#define __Project_2__AddStatement__

#include "Statement.h"

class AddStatement : public Statement
{
private:
    char m_variableName;
    int m_value;
    
    
public:
    AddStatement(char variableName, int value);
	
	virtual void execute(ProgramState * state, std::ostream &outf);
   
    virtual ~AddStatement(){};
};






#endif /* defined(__Project_2__AddStatement__) */
